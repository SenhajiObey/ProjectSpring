package be.vinci.ipl.services_users;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicesUsersApplicationTests {

	@Test
	void contextLoads() {
	}

}
